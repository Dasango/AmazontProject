
package controladores;

import javafx.fxml.FXML;
import javafx.scene.layout.VBox;

public class CartController {
	
	@FXML
	private VBox comprados;

}
