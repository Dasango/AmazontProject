package data;


public record User(Integer id, String name, String email, String password, String role, String avatar) {

	
}

