package data;

public record Category(Integer id, String name, String image) {

}
