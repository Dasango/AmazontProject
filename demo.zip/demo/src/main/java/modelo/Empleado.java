package modelo;

public record Empleado(String nombre, String apellido, String departamento, double salario) { }
