package demo;

import java.util.List;

import modelo.Empleado;

public class Logic {

    private static String query = "SELECT e.first_name, e.last_name, d.dept_name, s.salary " +
            "FROM employees e " +
            "JOIN dept_emp de ON e.emp_no = de.emp_no " +
            "JOIN departments d ON de.dept_no = d.dept_no " +
            "JOIN salaries s ON e.emp_no = s.emp_no "+
            "LIMIT 100000";

    private static String dropTableSQL = "DROP TABLE IF EXISTS empleados;";
    private static String createTableSQL = "CREATE TABLE empleados ("
            + "id INT AUTO_INCREMENT PRIMARY KEY, "
            + "nombre VARCHAR(255), "
            + "apellido VARCHAR(255), "
            + "departamento VARCHAR(255), "
            + "salario DOUBLE"
            + ");";

    private static List<Empleado> empleados;

    public static void consulta() {
        // Registrar el tiempo inicial
        long startTime = System.currentTimeMillis();

        // Obtener la lista de empleados desde la base de datos
        List<Empleado> empleadosConsulta = AppConnection.getItemsFromDatabase(query);

        long endTime = System.currentTimeMillis(); // Registrar el tiempo final

        // Calcular e imprimir el tiempo de respuesta
        System.out.println("Tiempo de respuesta de la Consulta: " + (endTime - startTime) + " ms");
        empleados = empleadosConsulta;
    }

    public static void createTable() {
        AppConnection.createTable(dropTableSQL);
        AppConnection.createTable(createTableSQL);
    }

    public static void insertEmployeesBatch(int batchSize) {
        // Registrar el tiempo inicial
        long startTime = System.currentTimeMillis();

        // Insertar empleados en lotes
        AppConnection.insertEmployeesBatch(empleados, batchSize);

        long endTime = System.currentTimeMillis(); // Registrar el tiempo final

        // Calcular e imprimir el tiempo de respuesta
        System.out.println("Tiempo de respuesta con un batch de " + batchSize + ": " + (endTime - startTime) + " ms");

    }

    public static void closeConnection() {
        AppConnection.closeConnection(AppConnection.getMySQLConnection());
    }
    public static void truncateTable() {
        String truncateSQL = "TRUNCATE TABLE empleados";
        AppConnection.executeUpdate(truncateSQL);
    }

    public static List<Empleado> getEmpleados() {
        return empleados;
    }
}
