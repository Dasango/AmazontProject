package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.Empleado;

public class AppConnection {

    public static Connection getMySQLConnection() {
        String url = "jdbc:mysql://localhost:3344/employees";
        String user = "redis";
        String password = "redis";

        try {
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static List<Empleado> getItemsFromDatabase(String query) {
        List<Empleado> empleados = new ArrayList<>();
        Connection connection = null;
    
        try {
            connection = getMySQLConnection();
            if (connection != null) {
                var statement = connection.createStatement();
                var resultSet = statement.executeQuery(query);
    
                while (resultSet.next()) {
                    String nombre = resultSet.getString("first_name"); // first_name → nombre
                    String apellido = resultSet.getString("last_name"); // last_name → apellido
                    String departamento = resultSet.getString("dept_name"); // dept_name → departamento
                    double salario = resultSet.getDouble("salary"); // salary → salario
    
                    // Crear un nuevo Empleado y agregarlo a la lista
                    Empleado empleado = new Empleado(nombre, apellido, departamento, salario);
                    empleados.add(empleado);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection(connection);
        }
    
        return empleados;
    }
    

    public static void createTable(String sql) {
        try (Connection connection = getMySQLConnection();
             Statement statement = connection.createStatement()) {
    
            // Ejecutar la consulta de SQL (DROP o CREATE)
            statement.executeUpdate(sql);
            System.out.println("Query executed successfully: " + sql);
    
        } catch (SQLException e) {
            // Imprimir el error detallado para diagnóstico
            System.err.println("Error executing query: " + e.getMessage());
            e.printStackTrace();
        }
    }
    

    public static void insertEmployeesBatch(List<Empleado> empleados, int batchSize) {
        // La consulta SQL para insertar los empleados
        String insertSQL = "INSERT INTO empleados (nombre, apellido, departamento, salario) VALUES (?, ?, ?, ?)";
    
        try (Connection connection = getMySQLConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {
    
            connection.setAutoCommit(false); // Desactivamos el autocommit para manejar el batch
    
            int count = 0;
    
            // Iterar sobre todos los empleados y agregar al batch
            for (Empleado empleado : empleados) {
                preparedStatement.setString(1, empleado.nombre()); // Establecer el nombre
                preparedStatement.setString(2, empleado.apellido()); // Establecer el apellido
                preparedStatement.setString(3, empleado.departamento()); // Establecer el departamento
                preparedStatement.setDouble(4, empleado.salario()); // Establecer el salario
    
                preparedStatement.addBatch(); // Añadir la operación al batch
    
                count++;
    
                // Ejecutar el batch cuando alcanzamos el tamaño especificado
                if (count % batchSize == 0 || count == empleados.size()) {
                    preparedStatement.executeBatch(); // Ejecutar el batch
                    connection.commit(); // Confirmar los cambios
                }
            }
    
            System.out.println("Inserción en batch completada.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void executeUpdate(String sql) {
        Connection connection = getMySQLConnection();
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
}

