package demo;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import modelo.Empleado;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RedisConnection {

    private static JedisPool pool = new JedisPool("localhost", 6379); // Cambia host si no es localhost

    public static void insertEmployeesToRedis(List<Empleado> empleados) {
        try (Jedis jedis = pool.getResource()) {
            int i = 1; // Usamos un contador como clave única
            for (Empleado emp : empleados) {
                String key = "empleado:" + i++;

                Map<String, String> empMap = new HashMap<>();
                empMap.put("nombre", emp.nombre());
                empMap.put("apellido", emp.apellido());
                empMap.put("departamento", emp.departamento());
                empMap.put("salario", String.valueOf(emp.salario()));

                jedis.hset(key, empMap);
            }
        }
    }

    public static void close() {
        pool.close();
    }
    public static void clearAllEmployees() {
    try (Jedis jedis = pool.getResource()) {
        Set<String> keys = jedis.keys("empleado:*");
        if (!keys.isEmpty()) {
            jedis.del(keys.toArray(new String[0]));
        }
        System.out.println("Entradas anteriores en Redis eliminadas.");
        }

    }

    public static void consultaEmpleados() {
        try (Jedis jedis = pool.getResource()) {
            Set<String> keys = jedis.keys("empleado:*");
            for (String key : keys) {
                Map<String, String> empMap = jedis.hgetAll(key);
                
                // Mostrar solo el nombre, apellido y departamento
                String nombre = empMap.get("nombre");
                String apellido = empMap.get("apellido");
                String departamento = empMap.get("departamento");
                
            }
        }
    }
    
}
