package demo;


public class Main {

    public static void main(String[] args) {

        Logic.consulta();

        Logic.createTable();

        Logic.insertEmployeesBatch(1000);

        RedisConnection.clearAllEmployees();
        
        long startRedis = System.currentTimeMillis();
        RedisConnection.insertEmployeesToRedis(Logic.getEmpleados());
        long endRedis = System.currentTimeMillis();
        System.out.println("Tiempo de inserción en Redis: " + (endRedis - startRedis) + " ms");

        long startRedis2 = System.currentTimeMillis();
        RedisConnection.consultaEmpleados();
        long endRedis2 = System.currentTimeMillis();
        System.out.println("Tiempo de consulta en Redis: " + (endRedis2 - startRedis2) + " ms");

        Logic.closeConnection();
        RedisConnection.close();
    }
}
